import{c as t,i as e}from"./react.631694b7.js";import{A as r}from"./App.cba1a0e1.js";import{c as m,h as a}from"./scheduler.528b44eb.js";let o=m(a);t(document.getElementById("root")).render(o(e.StrictMode,null,o(r,null)));
//# sourceMappingURL=mount.7126f018.js.map
