const n=gon.environment;let o="/cable";n==="production"&&(o="wss://samuraicable-production.up.railway.app");const a={environment:n,cableUrl:o};export{a as g};
//# sourceMappingURL=global.4c9502f9.js.map
