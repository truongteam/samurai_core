import{i as o}from"./react.631694b7.js";import{A as e}from"./App.5c65d5fa.js";import{c as r,h as m}from"./scheduler.528b44eb.js";let t=r(m);o.createRoot(document.getElementById("root")).render(t(o.StrictMode,null,t(e,null)));
//# sourceMappingURL=mount.f87d5451.js.map
