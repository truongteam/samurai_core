import{c as o,h as r,v as p}from"./scheduler.cb961abc.js";o(r);const t=()=>p("div",{children:"Hello world 234"});export{t as A};
//# sourceMappingURL=App.47d1f3cf.js.map
