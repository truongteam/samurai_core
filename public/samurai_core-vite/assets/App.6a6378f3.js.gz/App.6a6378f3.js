import{j as r}from"./jsx-runtime.a9b62637.js";const e=()=>r("div",{children:"Hello world 234"});export{e as default};
//# sourceMappingURL=App.6a6378f3.js.map
