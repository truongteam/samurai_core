import{c as t,i as e}from"./react.435e6ff6.js";import{A as r}from"./App.34682671.js";import{c as m,h as a}from"./scheduler.cb961abc.js";let o=m(a);t(document.getElementById("root")).render(o(e.StrictMode,null,o(r,null)));
//# sourceMappingURL=mount.be178f72.js.map
