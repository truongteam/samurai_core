import{_ as o,c as r}from"./client.d1654e13.js";import{R as e,j as t}from"./jsx-runtime.a9b62637.js";const a=e.lazy(()=>o(()=>import("./App.3be524ec.js"),["assets/App.3be524ec.js","assets/jsx-runtime.a9b62637.js"]));r.createRoot(document.getElementById("root")).render(t(e.StrictMode,{children:t(a,{})}));
//# sourceMappingURL=mount.343b21c6.js.map
