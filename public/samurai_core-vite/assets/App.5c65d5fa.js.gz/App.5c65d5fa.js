import{c as o,h as r,w as p}from"./scheduler.528b44eb.js";o(r);const t=()=>p("div",{children:"Hello world 234"});export{t as A};
//# sourceMappingURL=App.5c65d5fa.js.map
