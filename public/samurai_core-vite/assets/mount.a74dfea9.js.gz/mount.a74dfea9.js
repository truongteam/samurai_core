import{_ as o,c as r}from"./client.d1654e13.js";import{R as e,j as t}from"./jsx-runtime.a9b62637.js";const a=e.lazy(()=>o(()=>import("./App.6a6378f3.js"),["assets/App.6a6378f3.js","assets/jsx-runtime.a9b62637.js"]));r.createRoot(document.getElementById("root")).render(t(e.StrictMode,{children:t(a,{})}));
//# sourceMappingURL=mount.a74dfea9.js.map
