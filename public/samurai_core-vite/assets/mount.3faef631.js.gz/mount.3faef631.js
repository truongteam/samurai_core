import{i as o}from"./react.435e6ff6.js";import{A as e}from"./App.47d1f3cf.js";import{c as r,h as m}from"./scheduler.cb961abc.js";let t=r(m);o.createRoot(document.getElementById("root")).render(t(o.StrictMode,null,t(e,null)));
//# sourceMappingURL=mount.3faef631.js.map
