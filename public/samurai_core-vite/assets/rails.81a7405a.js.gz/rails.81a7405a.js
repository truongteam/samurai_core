import{r as o}from"./redux-rails.8c6b1694.js";import"./_commonjsHelpers.042e6b4d.js";import"./redux.3c9f6592.js";import"./toPropertyKey.cf64b126.js";const r={baseUrl:"/api/",resources:{Todos:{controller:"todos"}}};o.middleWare(r);
//# sourceMappingURL=rails.81a7405a.js.map
