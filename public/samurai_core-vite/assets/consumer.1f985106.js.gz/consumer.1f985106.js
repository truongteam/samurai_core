import{c as o}from"./actioncable.974013a5.js";const e={},a=gon.environment;a==="production"?e.cable=o("wss://samuraicable-production.up.railway.app"):e.cable=o("/cable");const n=e.cable;export{n as c};
//# sourceMappingURL=consumer.1f985106.js.map
