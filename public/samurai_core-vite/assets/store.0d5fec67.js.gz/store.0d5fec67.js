import{c as o,b as r}from"./books.4da96270.js";import{r as s}from"./redux-rails.8c6b1694.js";import"./redux.3c9f6592.js";import"./toPropertyKey.cf64b126.js";import"./_commonjsHelpers.042e6b4d.js";const e={baseUrl:"https://your-site-url.com/api/",resources:{Todos:{controller:"todos"}}},m=o({reducer:{books:r,resources:s.apiReducer(e)}});export{m as s};
//# sourceMappingURL=store.0d5fec67.js.map
