function t(){import("data:text/javascript,")}export{t as __vite_legacy_guard};
