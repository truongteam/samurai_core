import{j as r}from"./jsx-runtime.84cb2727.js";const t=()=>r.jsx("div",{children:"Hello world 234"});export{t as default};
