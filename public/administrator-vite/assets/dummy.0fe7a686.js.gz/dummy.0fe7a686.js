import"./mount.98ad9d89.js";import"./client.220ae75e.js";import"./jsx-runtime.a9b62637.js";function t(){import("data:text/javascript,")}export{t as __vite_legacy_guard};
