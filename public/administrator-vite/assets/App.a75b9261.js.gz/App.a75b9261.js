import{j as r}from"./jsx-runtime.a9b62637.js";function o(){import("data:text/javascript,")}const e=()=>r("div",{children:"Hello world 234"});export{o as __vite_legacy_guard,e as default};
