System.register(["./mount.d268c33f-legacy.js","./client.ea487cdd-legacy.js","./jsx-runtime.d0387ac5-legacy.js"],(function(e,t){"use strict";return{setters:[null,null,null],execute:function(){}}}));
