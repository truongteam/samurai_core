System.register(["./jsx-runtime.d0387ac5-legacy.js"],(function(e,t){"use strict";var r;return{setters:[e=>{r=e.j}],execute:function(){e("default",(()=>r("div",{children:"Hello world 234"})))}}}));
