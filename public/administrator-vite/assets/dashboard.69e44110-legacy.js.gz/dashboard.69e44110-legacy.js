System.register(["./mount.4bf4f6ec-legacy.js","./client.ea487cdd-legacy.js","./jsx-runtime.d0387ac5-legacy.js"],(function(e,t){"use strict";return{setters:[null,null,null],execute:function(){}}}));
